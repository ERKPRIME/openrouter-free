# opencode-free-router

[![ci](https://github.com/ERKPRIME/openrouter-free/actions/workflows/ci.yml/badge.svg)](https://github.com/ERKPRIME/openrouter-free/actions/workflows/ci.yml)
[![Coverage Status](https://coveralls.io/repos/github/ERKPRIME/openrouter-free/badge.svg?branch=master)](https://coveralls.io/github/ERKPRIME/openrouter-free?branch=master)

An [opencode](https://opencode.ai) plugin that always runs on the **best free model available right
now**, so you never have to track which free models exist this week.

You pick one model, `free/auto`, and the plugin does the rest:

- **Ranked, not random.** Every free model opencode can reach is scored with
  [LMArena](https://huggingface.co/datasets/lmarena-ai/leaderboard-dataset) (agent, webdev and text
  boards) and [Artificial Analysis](https://artificialanalysis.ai) (coding, agentic and intelligence
  indices). New stealth models that have no benchmarks yet, like the ones OpenRouter and OpenCode Zen
  run for a week, are detected and placed near the top.
- **Sticky.** A session keeps its model. It doesn't switch on every request. When a better model shows up, new sessions get it.
- **Fails over.** When the model hits its quota or rate limit, gets removed, or is refused, it goes on
  cooldown and the session moves to the next-ranked model. The interrupted task then continues automatically.
- **Only free.** Free providers are an explicit allowlist, and each pick is re-checked against
  live provider data. Subscription plans that report a price of 0 are never used.

```
$ opencode-free run "explain this repo"
> build · space-bunny-free
```

## Install

Requires **opencode 2** (`opencode --version` says 2.x) and Node 22.18+ (or Bun), on macOS, Linux or
Windows. The code is TypeScript and ships as source: opencode loads the plugin directly, and Node
22.18+ or Bun runs the ranker without a build step.

If you upgrade opencode from 1.x to 2, run the installer again: the 1.x plugin does not load on 2, and
it moves the `plugin` entry of your `free.jsonc` to the `plugins` entry opencode 2 reads.

### npm (recommended)

```sh
npm install -g openrouter-free
openrouter-free
```

The first run creates the data directory, ranks the free models and opens the TUI. Nothing is written
inside `node_modules`: the CLI mirrors the code it runs into your data directory, because Node refuses
to strip types under `node_modules` and `rank.mts` is TypeScript.

On Windows, `npm install -g` works from PowerShell or Command Prompt and installs an
`openrouter-free.cmd` shim next to your global `node`. If the command is not found afterwards, the npm
global bin directory is not on `PATH`; `npm config get prefix` prints it.

Data lives in:

| Platform | Directory |
|---|---|
| Windows | `%APPDATA%\openrouter-free` |
| macOS | `~/Library/Application Support/openrouter-free` |
| Linux | `$XDG_CONFIG_HOME/openrouter-free`, else `~/.config/openrouter-free` |

Set `FREE_ROUTER_DIR` to use another directory. Provider keys go in `providers.env` there (optional:
keys you already have via `opencode auth login` work without it).

### From a checkout (`scripts/install.sh`)

The shell installer keeps everything, code included, in one directory: `~/.config/opencode/free-router`
(or `$XDG_CONFIG_HOME/…`, or `--dir PATH`). It runs the first ranking and links `opencode-free` into
`~/.local/bin` if that is on your `PATH`. Re-run it to upgrade. Your config, pins, keys and state are
never overwritten. It is a separate install from the npm package; use `FREE_ROUTER_DIR` to share one
data directory between them.

#### Windows (Command Prompt or PowerShell)

```bat
git clone https://github.com/ERKPRIME/openrouter-free.git
cd openrouter-free
install.cmd          # add --bb to also register a bb agent
```

```powershell
git clone https://github.com/ERKPRIME/openrouter-free.git
cd openrouter-free
.\install.ps1        # add -Bb to also register a bb agent
```

`install.cmd` and `install.ps1` only locate Git Bash and run `scripts/install.sh`; Git for Windows
ships one. If it is not found, run `scripts/install.sh` yourself with any POSIX shell (Git Bash, WSL).
On Windows the installer also writes `opencode-free.cmd` and `opencode-free.ps1` next to the POSIX
`opencode-free`, so the launcher works from Command Prompt and PowerShell without Git Bash.

#### macOS, Linux, Git Bash, or WSL

```sh
git clone https://github.com/ERKPRIME/openrouter-free.git
cd openrouter-free
./scripts/install.sh          # add --bb to also register a bb agent
```

To pin a release instead of tracking `master`, `git checkout vX.Y.Z` (see
[releases](https://github.com/ERKPRIME/openrouter-free/releases)) before running it.

### Running it

```sh
openrouter-free                # npm: TUI on free/auto
opencode-free                  # install.sh: the same launcher
openrouter-free run "..."      # one-shot
openrouter-free acp            # ACP agent (Zed, JetBrains, bb, ...)
openrouter-free doctor         # versions, paths, what is missing
openrouter-free rank --status  # ranking, cooldowns, model per session
```

`openrouter-free` is the same as `opencode-free`, and both are plain `opencode` with the free-router
config layered on top via `OPENCODE_CONFIG`. Your normal `opencode` is unaffected. opencode 2 commands
normally talk to a shared background service that ignores that variable, so the wrapper runs each of
them with its own private server (`--standalone`). Three consequences: `openrouter-free service` (and
`serve --service`) is refused; so are the commands that manage, restart or may auto-start that service
(`debug`, `pair`, `mcp`, `plugin`, `upgrade`, `update`, `uninstall`), because it could come up with the
free-router config and your provider keys, so run those as plain `opencode`; and a `run` message has to
be quoted, because an unquoted word `service` in it is refused too:

```sh
openrouter-free run "restart the service"    # not: openrouter-free run restart the service
```

## Which free models

Without any keys you get OpenCode Zen's free models. Each key you add grows the pool:

| Provider | Key | What counts as free |
|---|---|---|
| OpenCode Zen | none | models priced 0 (`*-free`, big-pickle, …) |
| OpenRouter | `OPENROUTER_API_KEY` | `:free` models (its routers like `openrouter/auto` are excluded) |
| NVIDIA | `NVIDIA_API_KEY` | models priced 0 on build.nvidia.com |
| Z.AI | `ZHIPU_API_KEY` | models priced 0 (GLM-4.7-Flash, GLM-4.5-Flash, GLM-4.6V-Flash) |
| Zhipu AI | `ZHIPU_API_KEY` | the same free GLM Flash models, for a China (BigModel) account |
| ModelScope | `MODELSCOPE_API_KEY` | models priced 0, which is all of them (2,000 requests a day) |
| Mistral | `MISTRAL_API_KEY` | Devstral Small, Codestral and Mistral Small, via the free Experiment plan |
| Groq | `GROQ_API_KEY` | all models, via the free tier |
| Cerebras | `CEREBRAS_API_KEY` | all models, via the free tier |
| Google AI Studio | `GOOGLE_GENERATIVE_AI_API_KEY` | Flash and Gemma models, via the free tier |

Keys you already have through `opencode auth login` or your shell environment just work. Otherwise
put them in `~/.config/opencode/free-router/providers.env`. That also covers launches that don't read
your shell profile, like bb or GUI apps. **Use free-plan accounts**: Groq, Cerebras, Google and
Mistral models count as free because of their free tiers, so a key with billing enabled may be
charged.

The four additions have their own caveats:

- **Z.AI / Zhipu.** The free GLM Flash models are free for every account, not trial credits. The
  catch is throughput: one request at a time, about one a second. They are two separate platforms
  sharing one variable, `ZHIPU_API_KEY`: a z.ai key only works on `zai`, a BigModel (China) key only
  on `zhipuai`. opencode reads the key for both, the wrong endpoint answers 401, and that provider
  goes on a 24-hour cooldown, so exactly one of the two ever reaches the pool.
- **ModelScope.** Everything it serves is free, with a quota of 2,000 requests a day (500 per model)
  and no card, but signup wants a phone number and the endpoint is fastest inside Asia.
- **Mistral.** The Experiment plan (no card, 1B tokens a month, 1 request a second) covers Devstral
  Small 2, Codestral and Mistral Small, but the catalog prices them, so the router matches them by
  name. Right now that means Codestral and Mistral Small: every Devstral entry Mistral lists is
  marked deprecated, including its only 0-priced one, and the router skips those. The Devstral glob
  is there for the first current Devstral Small that appears. Tune the families in `config.json` if
  Mistral changes the plan:
  `{"mistral": ["$zero", "devstral-small*", "codestral*", "mistral-small*"]}`.

Left out on purpose, because a price of 0 there does not mean free: Cloudflare Workers AI (10,000
neurons a day, and the models its free plan dropped now answer 403, which would bench the whole
provider), Vercel AI Gateway (the free credits need a payment method, and the catalog marks Llama
models as 0 that Vercel actually prices), Hugging Face ($0.10 of monthly credits), and the many
gateway clones that list every model at 0.

An optional `ARTIFICIAL_ANALYSIS_API_KEY` in `ranker.env` adds Artificial Analysis scores (free key,
100 requests a day; the ranker uses a few per refresh). Without it, ranking uses LMArena only.

## How ranking works

`rank.mts` writes `ranking.json`. The plugin re-runs it in the background whenever the file is older
than `refreshHours` (6).

1. It lists the models opencode can reach (`opencode api --standalone model.list`) and keeps the ones that
   are free, can call tools, are enabled, and have at least 64k context. A model with several price
   tiers counts as free only if every tier is.
2. It matches each model against the leaderboards by name. `mimo-v2.6-flash` never matches
   `mimo-v2.6-pro`, and AA's `ling-3-0-flash-fin` matches `ling-3.0-flash-fin-free`.
3. Each source becomes a percentile. The score is the weighted mean over the sources that matched.
4. Models with no benchmarks: stealth models (OpenRouter's `stealth/` listing) score 0.95. Others
   score about 0.25–0.35, less for small models, so an unknown 2B preview never beats a
   benchmarked model.

```sh
node %APPDATA%\openrouter-free\rank.mts --status    # npm on Windows
node ~/.config/openrouter-free/rank.mts --status   # npm on Linux
node "$HOME/Library/Application Support/openrouter-free/rank.mts" --status  # npm on macOS
node ~/.config/opencode/free-router/rank.mts --status  # scripts/install.sh
```

### Overrides: `pins.json`

```json
{
  "pin":   ["opencode/space-bunny-free"],
  "ban":   ["openrouter/liquid/lfm-2.5-2.6b:free"],
  "alias": { "opencode/some-model-free": "name-on-the-leaderboard" }
}
```

`pin` forces models to the top in that order, `ban` never uses them, and `alias` fixes a missed benchmark
match. Run `rank.mts` after editing.

### Settings: `config.json`

Everything is optional. Nested maps merge with the defaults key by key.

| Key | Default | Meaning |
|---|---|---|
| `freeTier` | see table above | allowlist: provider → model globs; `"$zero"` = models priced 0 |
| `excludeProviders` | `[]` | never use these, e.g. `["openrouter"]` for sensitive code |
| `minContext` | `64000` | minimum context window |
| `weights` | agent 0.35, webdev 0.35, text 0.15, AA coding 0.25, agentic 0.25, intelligence 0.15 | score weights |
| `stealthScore` | `0.95` | score for unbenchmarked stealth models |
| `cooldownMinutes` | quota 360, rate 10, server 5, unavailable 1440 | how long a failed model sits out, unless `retry-after` says longer |
| `maxSwitchesPerTurn` | `3` | failover budget per message |
| `autoContinue` | `true` | retry the failed turn on the next model; `false` fails the turn instead and the next message uses the new model |
| `refreshHours` | `6` | re-rank when `ranking.json` is older than this |

## Failover in detail

opencode keeps one model for a whole turn, including its own retries, which can wait up to fifteen
minutes on a rate limit. So when a request fails, the plugin looks at the error before opencode
retries:

1. If the model is to blame, it goes on cooldown, until `retry-after` if the provider sends one,
   otherwise the default above. A quota message, a removed model, or an auth or permission rejection (401/403) fails over at once; a
   rate limit or a server error after the second try, or at once when the wait would be over a minute.
   A context overflow, a cut-off answer or a content filter are not the model's fault and stay with
   opencode.
2. The session moves to the next-ranked model that isn't cooling down. If every model is cooling down, it
   uses the one that frees up first.
3. opencode retries the same request on the new model straight away, in the same turn. The partial
   answer of a request cut off half-way stays in the conversation and the new model continues from it.

At most `maxSwitchesPerTurn` switches happen per turn; after that the provider's error is shown at once
instead of being waited out. With `autoContinue` off the turn fails and the next message runs on the
new model.

**A failover sends the whole conversation to the next free provider without asking.** Everything said
in the session so far goes to the new model's provider, with that provider's data terms (see Privacy).

Where you can see a switch: the model shown by the TUI, the model ACP clients report, `router.log`
(`failover ...`) and `rank.mts --status`. There is no extra message in the conversation.

**Choosing a model yourself ends routing for that session.** After `/model` to anything but `free/auto`
the router leaves the session and its errors alone; `/model free/auto` hands it back.

## bb

`./scripts/install.sh --bb` registers a custom ACP agent **Free (auto)** (provider `acp-free`) that
runs `openrouter-free acp` (npm) or `opencode-free acp` (scripts install). Pick `free/auto` as its model.
No other bb agent is touched. If an older install shows only "Agent default" as the model, re-run the
installer with `--bb`. A failover happens inside the running prompt, so bb sees one prompt answered by
the new model; it no longer receives a queued "continue" message.

## Privacy

**Free models are usually paid for with your data.** Assume prompts and completions may be logged or
used for training:

- On OpenCode Zen, most free models are explicit exceptions to Zen's zero-retention policy. During the
  free period, data "may be used to improve the model" (Big Pickle, MiMo Flash, Ling Flash Fin). NVIDIA's free
  endpoints log usage ("do not submit personal or confidential data"). "Contributor" models such as
  Muse Spark Contributor Free train on your prompts. Some stealth models state zero retention. Check
  [Zen's privacy notes](https://opencode.ai/docs/zen/) for the current list.
- On OpenRouter, free providers may keep prompts.
- Groq, Cerebras, Google and Mistral free tiers follow each provider's own terms. So do Z.AI's free
  GLM Flash models and ModelScope's free inference.

Don't point `free/auto` at confidential or client code. To narrow the pool, `ban` specific models in
`pins.json` or list whole providers in `excludeProviders`. See [SECURITY.md](SECURITY.md).

## Troubleshooting

- `rank.mts --status` shows the ranking, warnings, active cooldowns, and which model each session uses.
- `router.log` in the data directory records picks, failovers and background refreshes (see "Install" for
  where it lives).
- `cache/candidates.json` holds what opencode reported for each model (without headers, request
  bodies and provider settings), which explains why a model was or wasn't eligible.

## Development

```sh
npm ci --ignore-scripts       # compiler and type definitions, for npm run check only
npm run check                 # type-check (TypeScript 7, strict)
npm test                      # unit tests (no network, no opencode 2)
npm run test:coverage         # same, plus coverage/lcov.info (Node 26+)
npm run lint:sh               # shellcheck
./scripts/e2e-failover.sh     # real opencode 2 + a fake 429 provider: failover, stickiness, fail-fast
```

## Update and uninstall

### npm
```sh
npm update -g openrouter-free        # update to the latest published version
npm uninstall -g openrouter-free     # remove the global command
```
Your data in `%APPDATA%\openrouter-free` (Windows), `~/Library/Application Support/openrouter-free`
(macOS) or `~/.config/openrouter-free` (Linux) is not removed by `npm uninstall`; delete it manually
if you want to purge everything. `FREE_ROUTER_DIR` can point it somewhere else.

### From a checkout
```sh
./scripts/uninstall.sh [--bb] [--purge]
```
This removes the code and the wrapper (and the bb agent with `--bb`). Your config, keys and state stay
unless you pass `--purge`.

## Publishing (manual)
```sh
npm login
npm publish
```
Publish only when authorized; this project does not publish automatically. Check `npm pack --dry-run`
and test the `.tgz` before publishing. Update the version in `package.json` and `CHANGELOG.md` first.

## Attribution


Model scores come from [LMArena](https://lmarena.ai) (`lmarena-ai/leaderboard-dataset`) and
[Artificial Analysis](https://artificialanalysis.ai). Not affiliated with either, or with opencode.

## License

[BSD-2-Clause](LICENSE)
